﻿namespace BlazorApp1.Components.Shared.Themes
{
    public class ThemeManagerModel
    {
        public string PrimaryColor { get; internal set; }
        public bool IsDarkMode { get; internal set; }
    }
}